import React, { useState } from 'react'
import classes from '../Css/Calculator.css'
import { Link } from 'react-router-dom'
export default function Calculator() {
  const [result, setResult] = useState('0')
  const handleClick = (e) => {
    setResult(result.concat(e.target.name))
  }
  const clear = () => {
    setResult('')
  }
  const calculate = () => {
    try {
      setResult(eval(result).toString())
    } catch (err) {
      setResult('Error')
    }
  }

  return (
    <>
      <div className="frame">
        <div className="f">
          <div className="back_button">
            <Link to="/">
              <div className="option1"> ⬅ BACK</div>
            </Link>
          </div>
        </div>
        <div className="">
          <form className="form">
            <input type="text" value={result} />
          </form>
          <div className="keys">
            <button onClick={clear} id="clear">
              clear
            </button>
            <button className="lightcolor" onClick={calculate} id="result">
              =
            </button>
            <button name="+" className="lightcolor" onClick={handleClick}>
              +
            </button>

            <button className="wh" name="7" onClick={handleClick}>
              7
            </button>
            <button name="8" className="wh" onClick={handleClick}>
              8
            </button>
            <button name="9" className="wh" onClick={handleClick}>
              9
            </button>
            <button name="-" className="lightcolor" onClick={handleClick}>
              &ndash;
            </button>
            <button name="4" className="wh" onClick={handleClick}>
              4
            </button>
            <button name="5" className="wh" onClick={handleClick}>
              5
            </button>
            <button name="6" className="wh" onClick={handleClick}>
              6
            </button>

            <button name="*" className="lightcolor" onClick={handleClick}>
              &times;
            </button>
            <button name="1" className="wh" onClick={handleClick}>
              1
            </button>
            <button name="2" className="wh" onClick={handleClick}>
              2
            </button>
            <button name="3" className="wh" onClick={handleClick}>
              3
            </button>

            <button name="/" className="lightcolor" onClick={handleClick}>
              &divide;
            </button>
          </div>
        </div>
      </div>
    </>
  )
}
