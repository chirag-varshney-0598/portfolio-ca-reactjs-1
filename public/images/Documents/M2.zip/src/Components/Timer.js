import React, { useState, useEffect } from 'react'
import '../Css/Timer.css'
import { Link } from 'react-router-dom'
function Timer(props) {
  const [second, setSecond] = useState('00')
  const [minute, setMinute] = useState('00')
  const [isActive, setIsActive] = useState(false)
  const [counter, setCounter] = useState(0)
  useEffect(() => {
    let intervalId

    if (isActive) {
      intervalId = setInterval(() => {
        const secondCounter = counter % 60
        const minuteCounter = Math.floor(counter / 60)

        const computedSecond =
          String(secondCounter).length === 1
            ? `0${secondCounter}`
            : secondCounter
        const computedMinute =
          String(minuteCounter).length === 1
            ? `0${minuteCounter}`
            : minuteCounter

        setSecond(computedSecond)
        setMinute(computedMinute)

        setCounter((counter) => counter + 1)
      }, 1000)
    }

    return () => clearInterval(intervalId)
  }, [isActive, counter])

  function stopTimer() {
    setIsActive(false)
    setCounter(0)
    setSecond('00')
    setMinute('00')
  }

  return (
    <div className="timer">
      <div className="f">
        <div className="back_button">
          <Link to="/">
            <div className="option1"> ⬅ BACK</div>
          </Link>
        </div>
      </div>
      <div className="template2">
        <div className="frame_clock">
          <h2>Count Down</h2>
          <div className="timer_time">
            <div className="min">
              <span>Min:</span>
              <input type="number" max="59" />
            </div>
            <div className="min" max="60">
              <span>Seconds:</span>
              <input type="number"></input>
            </div>
            <button onClick={() => setIsActive(!isActive)}>
              {isActive ? 'Reset' : 'Start'}
            </button>
          </div>
          <div className="clock">
            <h3>{minute}:</h3>
            <h3>{second}</h3>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Timer
