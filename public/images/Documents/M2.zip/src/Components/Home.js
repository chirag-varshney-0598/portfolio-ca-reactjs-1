import React from 'react'
import classes from '../Css/Home.css'
import { Link } from 'react-router-dom'

function Home() {
  return (
    <div className="home">
      <div className="template">
        <h2>M2-TEST</h2>
        <div className="row">
          <Link to="/calculator">
            <div className="option">CALCI</div>
          </Link>
          <Link to="/timer">
            <div className="option">TIMER</div>
          </Link>
        </div>
      </div>
    </div>
  )
}

export default Home
