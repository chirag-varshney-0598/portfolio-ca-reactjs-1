import React from 'react'
import './App.css'
import Home from './Components/Home'
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom'
import Calculator from './Components/Calculator'
import Timer from './Components/Timer'
function App() {
  return (
    <div className="App">
      <Router>
        <Switch>
          <Route exact path="/">
            <Home />
          </Route>
        </Switch>

        <Switch>
          <Route exact path="/calculator">
            <Calculator />
          </Route>
        </Switch>

        <Switch>
          <Route exact path="/timer">
            <Timer />
          </Route>
        </Switch>
      </Router>
    </div>
  )
}

export default App
